﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dron : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

public class DroneHearing : MonoBehaviour
{
    public float hearingRange = 10f;

    private void Update()
    {
        DetectNoise();
    }

    private void DetectNoise()
    {
        // Проверка наличия объектов в радиусе слуха дрона
        Collider[] colliders = Physics.OverlapSphere(transform.position, hearingRange);

        foreach (Collider collider in colliders)
        {
            // Проверка, является ли объект источником шума (например, используйте тег или другой способ идентификации)
            if (collider.CompareTag("NoiseSource"))
            {
                // Получите направление от дрона к источнику шума
                Vector3 directionToNoise = collider.transform.position - transform.position;

                // Вычислите угол между направлением дрона и направлением к источнику шума
                float angleToNoise = Vector3.Angle(transform.forward, directionToNoise);

                // Ваша логика обработки услышанного шума и определения его направления
                Debug.Log("Drone heard a noise from direction: " + directionToNoise.normalized);
            }
        }
    }
}
public class DroneSmellTrigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // Логика, выполняемая при входе в зону
        if (other.CompareTag("SomethingToSmell"))
        {
            // Ваш код обработки обоняния
        }
    }

    private void OnTriggerExit(Collider other)
    {
        // Логика, выполняемая при выходе из зоны
        if (other.CompareTag("SomethingToSmell"))
        {
            // Ваш код обработки завершения обоняния
        }
    }
}
